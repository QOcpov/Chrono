import { View, Text, State, Chrono } from 'chrono-core';

function App() {
  const [count, setCount] = State(0);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text fontSize={24}>Hello Chrono!</Text>
      <Text>Count: {count}</Text>
      <Button onClick={() => setCount(count + 1)}>
        Increment
      </Button>
    </View>
  );
}

export default App;

