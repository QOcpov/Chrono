import * as fs from 'fs-extra';
import * as path from 'path';

function createProject(projectName: string) {
  const projectPath = path.join(process.cwd(), projectName);
  const templatePath = path.join(__dirname, '../templates/default-project');

  if (fs.existsSync(projectPath)) {
    console.error(`Error: Directory '${projectName}' already exists.`);
    process.exit(1);
  }

  try {
    fs.copySync(templatePath, projectPath);

    // Replace placeholder in package.json
    const packageJsonPath = path.join(projectPath, 'package.json');
    let packageJson = fs.readFileSync(packageJsonPath, 'utf8');
    packageJson = packageJson.replace('"{{projectName}}"', `"${projectName}"`);
    fs.writeFileSync(packageJsonPath, packageJson);

    console.log(`Chrono project '${projectName}' created successfully at ${projectPath}`);
    console.log('Next steps:');
    console.log(`  cd ${projectName}`);
    console.log('  npm install');
    console.log('  npm run watchos (or npm run wearos)');

  } catch (error) {
    console.error('Failed to create project:', error);
    process.exit(1);
  }
}

const args = process.argv.slice(2);

if (args[0] === 'create' && args[1]) {
  createProject(args[1]);
} else {
  console.log('Usage: chrono create <project-name>');
}

