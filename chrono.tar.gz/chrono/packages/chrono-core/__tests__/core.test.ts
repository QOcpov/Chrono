import { View, Text, Button, List, State, Chrono } from '../src';

describe("Chrono Core Components", () => {
  it("View component should render children", () => {
    const children = "Hello World";
    const view = View({ children });
    expect(view).toBe(children);
  });

  it("Text component should render children", () => {
    const children = "Some Text";
    const text = Text({ children });
    expect(text).toBe(children);
  });

  it("Button component should render children", () => {
    const children = "Click Me";
    const button = Button({ children });
    expect(button).toBe(children);
  });

  it("List component should render children", () => {
    const children = "List Item";
    const list = List({ children });
    expect(list).toBe(children);
  });
});

describe("Chrono State Management", () => {
  it("State hook should return initial value and setter", () => {
    const [count, setCount] = State(0);
    expect(count).toBe(0);
    setCount(1);
    // Note: In a real framework, this would trigger a re-render.
    // For this test, we just check the console log or a mock.
  });
});

describe("Chrono Connect", () => {
  it("syncedState should return initial value", () => {
    const status = Chrono.syncedState("orderStatus", "Pending");
    expect(status.value).toBe("Pending");
  });

  it("sendMessage should log the message", () => {
    const consoleSpy = jest.spyOn(console, "log");
    Chrono.sendMessage({ type: "TEST_MESSAGE", data: "hello" });
    expect(consoleSpy).toHaveBeenCalledWith("Sending message to phone:", { type: "TEST_MESSAGE", data: "hello" });
    consoleSpy.mockRestore();
  });
});


