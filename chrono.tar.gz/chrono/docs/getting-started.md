# Getting Started with Chrono

Welcome to Chrono, the framework for building high-performance, cross-platform watch applications. This guide will help you set up your development environment and create your first Chrono project.

## Prerequisites

Before you begin, ensure you have the following installed:

*   **Node.js (LTS version):** Chrono CLI and development tools are built with Node.js. You can download it from [nodejs.org](https://nodejs.org/).
*   **npm (Node Package Manager):** Comes bundled with Node.js.
*   **TypeScript:** While not strictly required globally, it's good practice to have it installed: `npm install -g typescript`.
*   **Android Studio:** For Wear OS development, you'll need Android Studio to install the necessary SDKs and set up emulators. Download from [developer.android.com/studio](https://developer.android.com/studio).
*   **Xcode (macOS only):** For watchOS development, you'll need Xcode to install the necessary SDKs and set up simulators. Download from the Mac App Store.

## 1. Install the Chrono CLI

The Chrono Command Line Interface (CLI) is your primary tool for creating, developing, and building Chrono applications. Install it globally using npm:

```bash
npm install -g chrono-cli
```

## 2. Create Your First Chrono Project

Once the CLI is installed, you can create a new project with a single command:

```bash
chrono create my-first-watch-app
```

This command will:

*   Create a new directory named `my-first-watch-app`.
*   Scaffold a basic Chrono project structure inside it.
*   Install the necessary dependencies.

## 3. Explore Your Project

Navigate into your newly created project directory:

```bash
cd my-first-watch-app
```

You will find a structure similar to this:

```
my-first-watch-app/
├── package.json
├── src/
│   └── watch/
│       ├── App.ts
│       └── index.ts
└── tsconfig.json
```

*   `package.json`: Project dependencies and scripts.
*   `src/watch/App.ts`: Your main watch application component.
*   `src/watch/index.ts`: The entry point for your watch application.

## 4. Run Your App

Chrono allows you to run your app on both watchOS and Wear OS emulators/simulators. Make sure you have at least one emulator/simulator set up and running for the platform you wish to target.

To run on Wear OS:

```bash
npm run wearos
```

To run on watchOS:

```bash
npm run watchos
```

These commands will compile your Chrono application and launch it on the respective emulator or connected physical device.

## Next Steps

*   **Learn about Chrono Components:** Dive into the core UI components like `View`, `Text`, `Button`, and `List`.
*   **Understand State Management:** Learn how to manage application state and synchronize data with companion phone apps using `Chrono.State` and `Chrono.syncedState`.
*   **Explore Chrono Connect:** Discover how to build seamless communication between your watch app and your mobile app.

Happy coding with Chrono!

