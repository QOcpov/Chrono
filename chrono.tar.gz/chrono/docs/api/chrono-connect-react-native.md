# Chrono Connect React Native API Reference

This document provides a comprehensive reference for the `chrono-connect-react-native` package, which allows your React Native mobile application to communicate with a Chrono watch app.

## Functions

### `syncState<T>(key: string, value: T)`

Sends data from the React Native mobile app to the connected Chrono watch app to synchronize a specific piece of state. The watch app can then access this state using `Chrono.syncedState`.

**Parameters:**

*   `key`: (string) A unique identifier for the state being synchronized. This key must match the one used in `Chrono.syncedState` on the watch side.
*   `value`: (T) The data to send. This can be any serializable JavaScript value (e.g., string, number, boolean, object, array).

**Example:**

```typescript
import { syncState } from 'chrono-connect-react-native';

// When a user's login status changes
syncState('userLoginStatus', { loggedIn: true, userId: 'abc-123' });

// When an order status updates
syncState('orderStatus', 'Shipped');
```

### `sendMessage(message: any)`

Sends a one-time message from the React Native mobile app to the connected Chrono watch app. This is useful for triggering actions or sending transient data that doesn't need to be persistently synchronized.

**Parameters:**

*   `message`: (any) The data to send. This can be any serializable JavaScript object.

**Example:**

```typescript
import { sendMessage } from 'chrono-connect-react-native';

// Request the watch to refresh its data
sendMessage({ type: 'REFRESH_DATA', payload: { source: 'mobile' } });

// Send a notification trigger
sendMessage({ type: 'SHOW_NOTIFICATION', title: 'New Message', body: 'You have a new message from John.' });
```


