# Chrono Core API Reference

This document provides a comprehensive reference for all components and APIs available in the `chrono-core` package.

## Components

### `<View>`

A fundamental container component for laying out UI elements. It maps to native view equivalents on watchOS (e.g., `VStack`, `HStack`, `ZStack` in SwiftUI) and Wear OS (e.g., `Box`, `Column`, `Row` in Compose).

**Props:**

*   `style`: (Object) A style object to apply to the view. Supports properties like `flex`, `justifyContent`, `alignItems`, `padding`, `margin`, `backgroundColor`, etc.
*   `children`: (React.Node) The child elements to be rendered within the view.

**Example:**

```typescript
import { View } from 'chrono-core';

<View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'black' }}>
  {/* Child components here */}
</View>
```

### `<Text>`

A component for displaying text.

**Props:**

*   `children`: (string) The text content to display.
*   `fontSize`: (number) The size of the font.
*   `fontWeight`: (string) The weight of the font (e.g., 'normal', 'bold', '100'-'900').
*   `color`: (string) The color of the text (e.g., 'red', '#FFFFFF').
*   `style`: (Object) Additional style properties.

**Example:**

```typescript
import { Text } from 'chrono-core';

<Text fontSize={20} fontWeight="bold" color="white">
  Hello Chrono!
</Text>
```

### `<Button>`

A component for interactive buttons.

**Props:**

*   `onClick`: (function) A callback function invoked when the button is pressed.
*   `children`: (React.Node) The content to display inside the button (usually a `<Text>` component).
*   `style`: (Object) Additional style properties.

**Example:**

```typescript
import { Button, Text } from 'chrono-core';

<Button onClick={() => console.log('Button pressed!')}>
  <Text>Press Me</Text>
</Button>
```

### `<List>`

A component for displaying scrollable lists of items.

**Props:**

*   `data`: (Array) An array of data items to render.
*   `renderItem`: (function) A function that takes an item from `data` and its index, and returns a Chrono component to render for that item.
*   `keyExtractor`: (function) (Optional) A function that takes an item and its index, and returns a unique key for that item. Defaults to using the index.
*   `style`: (Object) Additional style properties.

**Example:**

```typescript
import { List, Text, View } from 'chrono-core';

const items = ['Item 1', 'Item 2', 'Item 3'];

<List
  data={items}
  renderItem={({ item }) => (
    <View style={{ padding: 10, borderBottomWidth: 1, borderBottomColor: 'gray' }}>
      <Text>{item}</Text>
    </View>
  )}
/>
```

## Hooks

### `State<T>(initialValue: T)`

A hook for managing local component state. Returns a tuple containing the current state value and a setter function to update it.

**Parameters:**

*   `initialValue`: (T) The initial value of the state.

**Returns:**

*   `[value: T, setter: (newValue: T) => void]`

**Example:**

```typescript
import { State, Text, Button, View } from 'chrono-core';

function Counter() {
  const [count, setCount] = State(0);

  return (
    <View>
      <Text>Count: {count}</Text>
      <Button onClick={() => setCount(count + 1)}>
        Increment
      </Button>
    </View>
  );
}
```

## Chrono Object

The `Chrono` object provides access to platform-specific APIs and communication utilities.

### `Chrono.syncedState<T>(key: string, initialValue: T)`

A utility for synchronizing state between the watch app and its companion phone app. The watch app will automatically receive updates from the phone for the given `key`.

**Parameters:**

*   `key`: (string) A unique identifier for the synchronized state.
*   `initialValue`: (T) The initial value of the state on the watch.

**Returns:**

*   `{ value: T }`: An object containing the current synchronized value. This object will be updated automatically when the phone sends new data for this key.

**Example:**

```typescript
import { Chrono, Text } from 'chrono-core';

const orderStatus = Chrono.syncedState('orderStatus', 'Unknown');

<Text>Order Status: {orderStatus.value}</Text>
```

### `Chrono.sendMessage(message: any)`

Sends a message from the watch app to its companion phone app.

**Parameters:**

*   `message`: (any) The data to send to the phone. This can be any serializable JavaScript object.

**Example:**

```typescript
import { Chrono, Button, Text } from 'chrono-core';

<Button onClick={() => Chrono.sendMessage({ type: 'REQUEST_DATA', payload: { userId: '123' } })}>
  <Text>Request Data from Phone</Text>
</Button>
```


