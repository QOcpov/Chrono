# Chrono Connect Flutter API Reference

This document provides a comprehensive reference for the `chrono_connect_flutter` package, which allows your Flutter mobile application to communicate with a Chrono watch app.

## Functions

### `syncState<T>(String key, T value)`

Sends data from the Flutter mobile app to the connected Chrono watch app to synchronize a specific piece of state. The watch app can then access this state using `Chrono.syncedState`.

**Parameters:**

*   `key`: (String) A unique identifier for the state being synchronized. This key must match the one used in `Chrono.syncedState` on the watch side.
*   `value`: (T) The data to send. This can be any serializable Dart value (e.g., String, int, bool, Map, List).

**Example:**

```dart
import 'package:chrono_connect_flutter/chrono_connect.dart';

// When a user's login status changes
ChronoConnect.syncState('userLoginStatus', {'loggedIn': true, 'userId': 'abc-123'});

// When an order status updates
ChronoConnect.syncState('orderStatus', 'Shipped');
```

### `sendMessage(dynamic message)`

Sends a one-time message from the Flutter mobile app to the connected Chrono watch app. This is useful for triggering actions or sending transient data that doesn't need to be persistently synchronized.

**Parameters:**

*   `message`: (dynamic) The data to send. This can be any serializable Dart object.

**Example:**

```dart
import 'package:chrono_connect_flutter/chrono_connect.dart';

// Request the watch to refresh its data
ChronoConnect.sendMessage({'type': 'REFRESH_DATA', 'payload': {'source': 'mobile'}});

// Send a notification trigger
ChronoConnect.sendMessage({'type': 'SHOW_NOTIFICATION', 'title': 'New Message', 'body': 'You have a new message from John.'});
```


